UPGRADE FROM 1.4.x to 1.5
=======================

### PHP-Extension

If you upgrade to version 1.5 you have to install the CURL-PHP-Extension (if you use REST-Requests).
